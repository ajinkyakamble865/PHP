<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<?php include_once 'header.php'; ?>

		<h1 class="heading">About page</h1>

		<img src="images/ajinkya.png" height="550px" width="1000px">
		<marquee><h2>PHP DEVELOPER</h2></marquee>
		<h2>About</h2>
		<div class="skills">
			<p>skills: -</p>
			<ul>
				<li><a href="index.php">Html,&nbsp;</a></li>
				<li><a href="about.php">CSS,&nbsp;</a></li>
				<li><a href="contact.php">JavaScript,&nbsp;</a></li>
				<li><a href="contact.php">PHP,&nbsp;</a></li>
				<li><a href="contact.php">MySQL,&nbsp;</a></li>
				<li><a href="contact.php">Laravel,&nbsp;</a></li>
				<li><a href="contact.php">CodeIgniter,&nbsp;</a></li>
				<li><a href="contact.php">Magento.&nbsp;</a></li>
			</ul>
		</div>
		<?php include_once 'footer.php'; ?>
	</div>
</body>
</html>