<?php

// print_r($_POST);
if (isset($_POST['name'])) {
	echo "Uesr name is : ".$_POST['name']."<br>";
	echo "Uesr email is : ".$_POST['email']."<br>";
	echo "Uesr password is : ".$_POST['password']."<br>";
	echo "Uesr skills is : ".implode(", ", $_POST['skills'])."<br>";
	echo "Uesr gender is : ".$_POST['gender']."<br>";
	echo "Uesr city is : ".$_POST['city']."<br>";
	echo "Uesr bio is : ".$_POST['bio']."<br>";
}
?>