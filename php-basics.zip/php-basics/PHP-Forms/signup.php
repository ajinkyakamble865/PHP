<?php


if ($_POST) {
	echo "Name :".$_POST['name'];
	echo "<br>";
	echo "Email :".$_POST['email'];
	echo "<br>";
	echo "Password :".$_POST['password'];
}
?>