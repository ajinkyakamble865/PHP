<?php

$diff = null;

$var1 = 0;
$var2 = 0.0;
$var3 = "0";
$var4 = false;
$var5 = array();
$var6 = "";

if (isset($diff)) {
	echo "true";
} else {
	echo "false";
}

echo "<br>";

if (empty($diff)) {
	echo "true";
} else {
	echo "false";
}

?>