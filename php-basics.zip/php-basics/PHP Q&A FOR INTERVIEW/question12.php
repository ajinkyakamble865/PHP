<?php

$name = "Ajinkya";
$$name = "Learing PHP";

echo "$name is $Ajinkya";

?>