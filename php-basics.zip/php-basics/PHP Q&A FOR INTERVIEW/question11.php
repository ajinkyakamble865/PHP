<?php

class MathTest
{
	public $total = 20;
	public static $count = 100;
}

$obj = new MathTest();

echo $obj->total;
echo "<br>";
echo MathTest::$count;

?>