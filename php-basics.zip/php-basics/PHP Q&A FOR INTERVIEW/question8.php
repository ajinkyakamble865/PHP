<?php

var_dump(20.100>20.1);

// Guess the Output

?>