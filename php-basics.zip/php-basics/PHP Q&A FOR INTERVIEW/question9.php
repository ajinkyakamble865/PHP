<?php

var_dump("1"==" 1");

echo "<br>";

var_dump(1 == 1  );

// Guess the Output
// A. ture and true
// B. false and true
// C. ture and false
// D. false and false
?>