<?php

$a = null;
$b;
$c="";

var_dump($a==$b);
echo "<br>";
var_dump($a===$b);
echo "<br>";
var_dump($a==$c);
echo "<br>";
var_dump($a===$c);
?>