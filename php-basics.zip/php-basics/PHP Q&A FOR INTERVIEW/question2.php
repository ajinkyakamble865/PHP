<?php

$arr = [ 20=>"apple", 1=>"a", "1"=>"b", true=>"c", 0=>"d"];

echo $arr[1];

?>