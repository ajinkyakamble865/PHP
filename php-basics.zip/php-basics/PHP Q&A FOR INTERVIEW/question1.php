<?php

$x = true && false; // this && operator on high priority

$x = true and false;

var_dump($x)

?>