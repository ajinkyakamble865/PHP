<?php

// sawp the value

$a = 20;
$b = 10;

$b = $a + $b; //30
$a = $b - $a; //20

$b = $b - $a; //10

echo "$a<br>";
echo $b;

?>