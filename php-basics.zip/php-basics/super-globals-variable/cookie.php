<?php 

setcookie("fruits","apple",time()+(86400));
setcookie("color","red",time()+(86400));

if (isset($_COOKIE['fruits'])) {
	echo "current cookie fruit is ".$_COOKIE['fruits'];
}else {
	echo "no cookies there";
}
echo "<br>";

if (isset($_COOKIE['color'])) {
	echo "current cookie color is ".$_COOKIE['color'];
}else {
	echo "no cookies there";
}

?>