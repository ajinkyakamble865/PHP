<?php
	session_start();

	if (isset($_POST['btn'])) {
		if ($_POST['btn'] == "set") {
			$val = $_POST['user'];
			$_SESSION['user']=$val;
		}

		if ($_POST['btn'] == "get") {
			if (isset($_SESSION['user'])) {
				echo $_SESSION['user'];
			}else{
				echo "there is a no Session";
			}
		}

		if ($_POST['btn'] == "delete") {
			session_destroy();
			echo "Session Deleted";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>session with html</title>
</head>
<body>
	<form action="" method="post">
		<input type="text" name="user" placeholder="Enter Your Name">
		<br>
		<br>
		<button name="btn" value="set">Set Session</button>
		<br>
		<br>
		<button name="btn" value="get">Get Session</button>
		<br>
		<br>
		<button name="btn" value="delete">Delete Session</button>
	</form>
</body>
</html>
