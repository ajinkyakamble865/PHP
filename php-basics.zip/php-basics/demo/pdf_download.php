<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pdfContent = isset($_POST['pdfContent']) ? $_POST['pdfContent'] : 'Default PDF Content';

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="Mass.pdf"');
    $pdf_content = "%PDF-1.4\n";
    $pdf_content .= "1 0 obj\n<<\n/Type /Catalog\n/Pages 2 0 R\n>>\nendobj\n";
    $pdf_content .= "2 0 obj\n<<\n/Type /Pages\n/Kids [3 0 R]\n/Count 1\n>>\nendobj\n";
    $pdf_content .= "3 0 obj\n<<\n/Type /Page\n/Parent 2 0 R\n/MediaBox [0 0 595 842]\n/Contents 4 0 R\n/Resources <<\n/Font << /F1 5 0 R >>\n>>\n>>\nendobj\n";
    $pdf_content .= "4 0 obj\n<< /Length 55 >>\nstream\n";

    // this is for insert content
    $pdf_content .= "BT\n/F1 24 Tf\n100 700 Td\n(" . $pdfContent . ") Tj\nET\n"; 
    // this is for insert content

    $pdf_content .= "endstream\nendobj\n";
    $pdf_content .= "5 0 obj\n<< /Type /Font\n/Subtype /Type1\n/BaseFont /Helvetica\n>>\nendobj\n";
    $pdf_content .= "xref\n0 6\n0000000000 65535 f \n0000000010 00000 n \n0000000053 00000 n \n0000000106 00000 n \n0000000272 00000 n \n0000000320 00000 n \n";
    $pdf_content .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n377\n%%EOF";

    // Output PDF content
    echo $pdf_content;
}
?>
