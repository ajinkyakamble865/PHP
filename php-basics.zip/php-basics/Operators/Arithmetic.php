<?php

// Arithmetic operators
$a = 20;
$b = 10;

echo "**********Arithmetic operators**********<br>";
echo "<br>";
echo $a + $b."<br>";  //Addition
echo $a - $b."<br>";  //Subtraction
echo $a * $b."<br>";  //Multiplication
echo $a / $b."<br>";  //Division
echo $a % $b."<br>";  //Modulus
echo $a ** $b."<br>"; //Exponentiation
echo "<br>";
echo "**********End**********<br><br>";

?>