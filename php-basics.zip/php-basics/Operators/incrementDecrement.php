<?php

$a = 10; 

echo ++$a .'<br>';	//Pre-increment	Increments $a by one, then returns $a

echo $a++ .'<br>';	//Post-increment Returns $a, then increments $a by one


echo --$a .'<br>';	//Pre-decrement	Decrements $x by one, then returns $x

echo $a-- .'<br>';	//Post-decrement	Returns $x, then decrements $x by one

?>