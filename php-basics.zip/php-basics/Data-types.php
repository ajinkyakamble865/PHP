<?php 

$name = "this is string"; //this is string datatype

var_dump($name);
echo "<br>=====================================<br>";



$num = 123; //this is integer datatype with normal number
var_dump($num);
echo "<br>=====================================<br>";


$float = 49.5; //this is float datatype with decimal number
var_dump($float);
echo "<br>=====================================<br>";


$bool = true; //this is boolean datatype boolean has only two value true and false
var_dump($bool);
echo "<br>=====================================<br>";

$abc = null; //this is null datatype
var_dump($abc);
echo "<br>=====================================<br>";

$arr = ["ajinkya",2,3.1,true,null]; // this is array datatype
var_dump($arr);
// print_r($arr);
echo "<br>=====================================<br>";

/**
 * 
 */
class ClassName
{
	public function __construct()
	{
		echo"this is object <br>";
	}
}

 $object = new className(); //this is object datatype we 
var_dump($object);
echo "<br>=====================================<br>";
?>