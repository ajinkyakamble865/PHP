<?php

function heading()
	{
		echo "<h2>User Detailes</h2>";
		// displayUserDetails();
	}

function displayUserDetails()
	{
		heading();
	 	echo "User Name : Ajinkya Kamble <br>";
	 	echo "User Age : 21 <br>";
	 	echo "Position : PHP Developer <br>";
	 	echo "<hr>";
	}

displayUserDetails();

displayUserDetails();


?>