<?php

function userName($name="Ajinkya",$color="red")
{
	echo "<h2 style='color:$color;'>$name</h2>";
}

// userColor("Ajinkya","blue");
// userColor("Kamble","red");
userName();
userName("karan","blue");
?>