<?php


// this is variable function

function test()
{
	echo "<h2>this is test function called</h2>";
}


$var = "test";

$var();

// this is callback function

function exclamationSign($a)
{
	echo $a . "! ";
}

function questionMark($value)
{
	echo $value ."? ";
}

function ask($value,$for)
{
	echo $for($value);
}

ask("Ajinkya","questionMark");

?>