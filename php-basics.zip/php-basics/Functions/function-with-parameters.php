<?php


function pluse($a,$b)
{
	echo $a + $b;
	echo "<br>";
}

pluse(10,50);


function multiplication($x,$y)
{
	echo $x * $y;
	echo "<br>";
}

multiplication(2,4);



function userColor($name,$color)
{
	echo "<h2 style='color:$color;'>$name</h2>";
}

userColor("Ajinkya","blue");
userColor("Lileshwar","red");

?>