<?php

$color = "black";


switch ($color) {
	case 'red':
		echo "this color is red";
		break;
	case 'blue':
		echo "this color is blue";
		break;
	case 'lemon':
		echo "this color is lemon";
		break;
	case 'green':
		echo "this color is green";
		break;	
	case 'black':
		echo "this color is black";
		break;
		
	default:
		echo "this color is not availbale";
		break;
}

?>