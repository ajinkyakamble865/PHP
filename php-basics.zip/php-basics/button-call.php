<?php
if (isset($_REQUEST['btn'])) {
	callBtn();
}else{
	echo"wrong method";
}
function callBtn()
{
	echo "this function is called";
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Call Button On Click</title>
</head>
<body>
	<form action="" method="post">
		<button name="btn">Call function</button>
	</form>
</body>
</html>