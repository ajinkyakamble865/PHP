<?php
include 'config.php';
$getStudent = $conn->prepare("SELECT id,name FROM students");
$getStudent->execute();
$StudentData = $getStudent->fetchAll();


// print_r($StudentData);


echo "<select>";
echo "<option>select your name</option>";

foreach ($StudentData as $students) {
	echo "<option value=".$students['id'].">".$students['name']."</option>";
}

echo "</select>";


?>