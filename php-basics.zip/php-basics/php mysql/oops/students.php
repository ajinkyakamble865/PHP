<?php

include 'config.php';

class Students
{
	public $DBconn;
	
	function __construct($conn)
	{
		$this->DBconn=$conn;
	}

	function getData()
	{
		$getStudents = $this->DBconn->prepare('SELECT * FROM students');
		$getStudents->execute();
		$result= $getStudents->fetchAll();
		// echo "<pre>";
		// print_r($result);
		
		echo "<table border=1>
			<tr>
				<th>Name</th>
				<th>Course</th>
				<th>Batch</th>
				<th>Year</th>
			</tr>	
		";

		foreach ($result as $students) {
			echo "<tr>
					<td>".$students['name']."</td>
					<td>".$students['course']."</td>
					<td>".$students['batch']."</td>
					<td>".$students['year']."</td>
				</tr>";
		}
		echo "</table>";
	}

	function insertData()
	{
		$sqlQuery = "INSERT INTO students (`id`,`name`,`course`,`batch`,`year`) VALUES (null,'Karan','B.tech','Afternoon','2nd')";
		$Student = $this->DBconn->prepare($sqlQuery);
		$result = $Student->execute();

		if ($result) {
			echo "Data Inserted";
		}else {
			echo "Somethings Missing";
		}
	}

	function updateData()
	{
		$sqlQuery = "UPDATE students set name='Yash',batch='evening' WHERE id=27";
		$Student = $this->DBconn->prepare($sqlQuery);
		$result = $Student->execute();

		if ($result) {
			echo "Data Updated";
		}else {
			echo "Somethings Missing";
		}
	}

	function deleteData()
	{
		$sqlQuery = "DELETE FROM students WHERE id=26";
		$Student = $this->DBconn->prepare($sqlQuery);
		$result = $Student->execute();

		if ($result) {
			echo "Data Deleted Successfully";
		}else {
			echo "Somethings Missing";
		}
	}

	function insertDataWithOops($request)
	{

		// print_r($request);
		$name = $request['name'];
		$course = $request['course'];
		$batch = $request['batch'];
		$year = $request['year'];
		$sqlQuery = "INSERT INTO students (`id`,`name`,`course`,`batch`,`year`) VALUES (null,'$name','$course','$batch','$year')";
		$Student = $this->DBconn->prepare($sqlQuery);
		$result = $Student->execute();

		if ($result) {
			echo "Data Inserted with oops";
		}else {
			echo "Somethings Missing";
		}
	}

}

$Students = new Students($conn);
$Students->getData();
// $Students->insertData();
// $Students->updateData();
$Students->deleteData();

echo "<br>";

if(isset($_POST['name'])) {
	$Students->insertDataWithOops($_POST);
}
?>