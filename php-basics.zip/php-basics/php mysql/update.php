<?php
include 'config.php';

	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$getStudent = $conn->prepare("SELECT * FROM students WHERE id='$id'");
		$getStudent->execute();
		$student = $getStudent->fetchAll();
		// print_r($student);
		$name = $student[0]['name'];
		$course = $student[0]['course'];
		$batch = $student[0]['batch'];
		$year = $student[0]['year'];
	}

	if (isset($_POST['update'])) {
		$id = $_POST['update'];
		$name = $_POST['name'];
		$course = $_POST['course'];
		$batch = $_POST['batch'];
		$year = $_POST['year'];
		$updateStudent = $conn->prepare("UPDATE students SET name='$name',course='$course',batch='$batch',year='$year' WHERE id='$id'");
		if($updateStudent->execute()){
			header('Location:delete_edit.php');
		}else{
			echo "delete faild";
		}
	}

?>

<form method="post">
	<input type="text" name="name" value="<?php echo $name;?>" placeholder="Enter Your Name">
	<br><br>
	<input type="text" name="course" value="<?php echo $course;?>" placeholder="Enter Your Course">
	<br><br>
	<input type="text" name="batch" value="<?php echo $batch;?>" placeholder="Enter Your Batch">
	<br><br>
	<input type="text" name="year" value="<?php echo $year;?>" placeholder="Enter Your Year">
	<br><br>
	<button name="update" value="<?php echo $id;?>">Update Student Data</button>
</form>