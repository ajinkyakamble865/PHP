<?php
include 'config.php';

$getData = $conn->prepare("SELECT * FROM students");
$getData->execute();
$StudentData = $getData->fetchAll();

echo "<table border=1>
	<tr>
		<th>Name</th>
		<th>Course</th>
		<th>Batch</th>
		<th>Year</th>
	</tr>	
";

foreach ($StudentData as $students) {
	echo "<tr>
			<td>".$students['name']."</td>
			<td>".$students['course']."</td>
			<td>".$students['batch']."</td>
			<td>".$students['year']."</td>
		</tr>";
}
echo "</table>";
?>