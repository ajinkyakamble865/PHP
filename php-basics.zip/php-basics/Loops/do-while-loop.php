<?php

// this is positive value

$num = 0;

do{
	echo"this is current value $num <br>";
	$num++;
}while($num<10);


echo "<br>";
// this is negative value

$abc = 10;

do{
	echo"this is current value $abc <br>";
	$abc--;
}while($abc>=0);

?>