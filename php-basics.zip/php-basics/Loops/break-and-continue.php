<?php

// break statement
$user_need = 7;

for($i=0; $i <= 10; $i++){
	echo $i;
	echo "<br>";
	if($i == $user_need){
		break;
	}
}

echo "<br><br>";

// continue statement

for ($i=0; $i <= 10; $i++) { 
	if ($i == 0 || $i == 9) {
		continue;
	}
	echo $i."<br>";
}


?>