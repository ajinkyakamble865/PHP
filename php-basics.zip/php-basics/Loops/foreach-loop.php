<?php

$users = ["Ajinkya","sam","peter","bruce","karan"];

foreach ($users as $x) {
	echo $x;
	echo "<br>";
}

echo"<br>";


foreach($users as $x):
	echo $x;
	echo "<br>";
endforeach;

?>