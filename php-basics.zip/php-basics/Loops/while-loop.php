<?php

// while loop positive value

$abc = 0;
while ($abc<10) {
	echo "$abc <br>";
	$abc++;
}

// while loop negative value
echo"<br>";
$num = 10;
while ($num>0) {
	echo "$num <br>";
	$num--;
}

?>