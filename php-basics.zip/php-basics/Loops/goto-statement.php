<?php

$x = 10;
echo "before goto statement <br>";

if ($x == 10) {
	goto abc;
}

$name = "Ajinkya Kamble<br>"; //this will be skip
echo $name;

abc:
echo"this is goto statement <br><br>";



// goto statement using loop
// for ($i=0; $i < 10; $i++) { 
// 	echo "$i <br>";
// 	if ($i==5) {
// 		goto out;
// 	}
// }

// $j=0;
// while ($j < 10) {
// 	echo "$j <br>";
// 	$j++;

// 	if ($j == 5) {
// 		goto out;
// 	}
// }

$m=0;
do{
	echo "$m <br>";
	$m++;

	if($m==5){
		goto out;
	}

}while($m<10);

out:
echo"loop is break";

?>