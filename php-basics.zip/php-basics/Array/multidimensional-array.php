<?php

$users = [
	[1,"Ajinkya",21,"ajinkya@test.com"],
	[2,"Naredra",43,"naredra@test.com"],
	[3,"Karan",18,"karan@test.com"],
];

// echo "<pre>";
// print_r($users);

for ($i=0; $i < count($users); $i++) { 
	// print_r($users);
	// echo "<br>";
	for ($j=0; $j < count($users[$i]); $j++) { 
		echo $users[$i][$j];
		echo "<br>";
	}
}


?>