<?php

$usersDetails = [
	"name" => "Ajinkya",
	"Age" => 21,
	"email" => "ajinkya@test.com",
	"city" => "Amravati"
];

// echo $usersDetails["name"];

foreach ($usersDetails as $key => $value) {
	echo $key ." is ".$value;
	echo"<br>";
}

echo "<br>";
foreach($usersDetails as $key => $value):
	echo $key ." is ".$value;
	echo"<br>";
endforeach;

?>