<?php

	$usersDetails = [
		[1,"Ajinkya",21,"Amravati"],
		[2,"Karan",18,"Amravati"],
		[3,"Naredra",43,"Pune"],
		[4,"Aboli",27,"Amravati"],
		[5,"Pari",15,"Amravati"],
	];
echo"<table border>";
	echo"<tr>
			<th>Sr.n</th>
			<th>Name</th>
			<th>Age</th>
			<th>City</th>	
		</tr>";
foreach ($usersDetails as $users) {
	// echo "<pre>";
	// print_r($users);
	echo"<tr>";
	foreach ($users as $key => $value) {
		echo"<td>";
		echo $value;
		echo "<br>";
		echo"</td>";
	}
	echo"</tr>";
}
echo"</table>";
?>