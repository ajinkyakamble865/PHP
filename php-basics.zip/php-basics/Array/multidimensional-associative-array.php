<?php

$usersDetails = [
	["Name"=>"Ajinka","Age"=>21,"email"=>"ajinkya@test.com"],
	["Name"=>"Narendra","Age"=>43,"email"=>"narendra@test.com"],
	["Name"=>"Karan","Age"=>18,"email"=>"karan@test.com"],
	["Name"=>"sam","Age"=>21,"email"=>"sam@test.com"],
];

foreach ($usersDetails as $user) {
	echo"<br>";

	foreach ($user as $key => $value) {
		echo "$key : $value";
		echo "<br>";
	}
}
?>