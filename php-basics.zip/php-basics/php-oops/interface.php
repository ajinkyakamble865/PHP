<?php

interface ProductFeature{
	function image();
	function ownerDetail();
}

class product implements ProductFeature {

	function image(){
		echo "Image";
	}
	function ownerDetail(){
		echo "Owner Detail";
	}
}


$obj = new product();
$obj->image();

?>