<?php

class Properties
{

		// public, private, protected
		public $name="Ajinkya";

		function getName(){
			echo $this->name;
		}

		function updateName($name)
		{
			$this->name=$name;
		}

}

$obj = new Properties();
// $obj->updateName("Kamble");
$obj->getName();

?>