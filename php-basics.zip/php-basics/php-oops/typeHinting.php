<?php

function fruit(string $name){
	echo $name;
}

fruit(["Apple"]);
?>