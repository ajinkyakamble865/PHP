<?php

class Teacher{
	private function questionPapers()
	{
		return "important";
	}

	public function exam()
	{
		if ($this->questionPapers()=="important") {
			echo "Do something";
		}else{
			echo "Do else";
		}
	}

	protected function studentMarks()
	{
		echo "Student Marks";
	}
}

class Management extends Teacher
{
	
	function review(){
		$this->studentMarks();
	}
}

$obj = new Teacher();
$obj->exam();

echo "<br>";

$management = new Management();
$management->review();
?>