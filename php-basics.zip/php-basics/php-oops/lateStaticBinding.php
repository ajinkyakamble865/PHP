<?php

class CountrySale{
	static public $totalSale="1000";
	function getTotalSale()
	{
		echo static::$totalSale;
	}

	function getAreaName(){
		static::AreaName();
	}

	function AreaName(){
		echo "India";
	}
}

class CitySale extends CountrySale{
	static public $totalSale="50";

	function AreaName(){
		echo "Pune";
	}
}

$obj = new CitySale();
$obj->getAreaName();
echo "<br>";
$obj->getTotalSale();

?>