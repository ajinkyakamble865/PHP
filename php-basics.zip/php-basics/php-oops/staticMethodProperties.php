<?php

class Demo
{
	static public $var="Hello";
	static function test()
	{
		echo "HI I AM IRON MAN";
	}
}

echo Demo::$var;
echo "<br>";
Demo::test();

?>