<?php

abstract class productFeatures{
	abstract function ProductDeatails();
	abstract function ProductImage();
	abstract function ProductOwnerDeatail();
	function test(){
		echo "additional method";
	}
}


class UploadProduct extends productFeatures
{
	function ProductDetails(){
		echo "Product Detail";
	}
	function ProductImage(){
		echo "Product Image";
	}
	function ProductOwnerDetail(){
		echo "Product Owner Detail";
	}
	function other(){
		echo "other additional method";
	}
}
// $obj = new productFeatures(); you cannot create object for abstract class

$obj = new UploadProduct();
$obj->ProductDetails();
echo "<br>";
$obj->ProductImage();
echo "<br>";
$obj->ProductOwnerDetail();
echo "<br>";
$obj->test();
echo "<br>";
$obj->other();
?>