<?php

class Teacher
{
	function age()
	{
		echo "my age is 40";
	}
}

class Student extends Teacher
{
	
	function age() //this fun is overrided
	{
		echo "my age is 21";
	}
}

$student = new Student();
$student->age();
?>