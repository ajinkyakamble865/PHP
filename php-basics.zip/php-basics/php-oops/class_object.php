<?php

class User {
	
	function add($a,$b)
	{
		return $a + $b .'<br>';
	}
	function sub($a,$b)
	{
		return $a - $b .'<br>';
	}
	function multi($a,$b)
	{
		return $a * $b .'<br>';
	}
	function division($a,$b)
	{
		return $a / $b .'<br>';
	}
}

$obj = new User();
echo $obj->add(20,10);
echo $obj->sub(20,10);
echo $obj->multi(20,10);
echo $obj->division(20,10);
?>