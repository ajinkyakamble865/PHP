<?php


trait parentCompany1{
	function getEmp(){
		echo 300;
	} 
}

trait parentCompany2{
	function getEmp(){
		echo 200;
	} 
}


class Company{
	use parentCompany1;
	use parentCompany2{
		parentCompany1::getEmp insteadOf parentCompany2;
		parentCompany2::getEmp as getEmpCompany2;
	}

}

$obj = new Company();
$obj->getEmp();
echo "<br>";
$obj->getEmpCompany2();

?>