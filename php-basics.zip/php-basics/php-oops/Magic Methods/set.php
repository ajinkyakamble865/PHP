<?php 

class User{

	private $name = "Karan";

	function __set($property,$value){

		if (property_exists($this,$property)) {
			$this->$property=$value;
		}else {
			echo "property in not exist";
		}

		// echo "$property property can not set with $value value as this property does not exist";
	}

	function getName(){
		echo $this->name;
	}

}

$obj = new User();
$obj->getName();
$obj->name="Ajinkya";

$obj->getName();

?>