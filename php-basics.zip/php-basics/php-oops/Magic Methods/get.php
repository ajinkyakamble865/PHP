<?php

class User{

	public $name = "Ajinkya Kamble";

	protected $city = "Amravati"; //not accessable directly

	private $age=30;//not accessable

	function __get($property){
		echo "$property property is not exist";
	}
	// Getter method for $city
    function getCity() {
        return $this->city;
    }
}

$obj = new User();
echo $obj->name;
echo "<br>";
echo $obj->age;
echo "<br>";
echo $obj->getCity();
?>