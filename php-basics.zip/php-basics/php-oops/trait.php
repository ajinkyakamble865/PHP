<?php

trait parentCompany1{
	function getTotalemp(){
		echo 500;
	}
}

trait parentCompany2{
	function getTotalOffice(){
		echo 10;
	}
}


class company{
	use parentCompany1;
	use parentCompany2;
}


$obj = new company();
$obj->getTotalemp();
echo "<br>";
$obj->getTotalOffice();
?>