<?php

	namespace teacher;
	
	class JoiningDetails
	{
		
		function JoiningDate()
		{
			echo "11/11/2024";
		}
	}

?>