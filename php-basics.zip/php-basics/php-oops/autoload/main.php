<?php 

// include 'Teacher.php';

function autoLoader($class){
	include ($class.'.php');
}

spl_autoload_register('autoLoader');


$obj = new Teacher();
echo "<br>";
$student = new Student();
echo "<br>";
$managment = new Managment();

?>