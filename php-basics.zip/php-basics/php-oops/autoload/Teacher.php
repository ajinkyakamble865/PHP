<?php

class Teacher
{
	
	function __construct()
	{
		echo "this is a Teacher class";
	}
}

?>