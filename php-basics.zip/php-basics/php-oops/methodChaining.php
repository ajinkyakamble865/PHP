<?php

class Company{

	function getName(){
		echo "Honda Moters. ";
		return $this;
	}
	function getEmp(){
		echo "Honda has 20000 Employee. ";
		return $this;
	}
	function getTotalOffice(){
		echo "Honda has 200 Offices";
	}
}

$company = new Company();
$company->getName()->getEmp()->getTotalOffice();

?>