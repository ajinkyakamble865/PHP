<?php

// variables (variables are changable)

$name = "This is variables";
$name = "this is name variable"; //this value is changed here
echo $name ."<br>";


// constant (constant not allow to change the value)
const data = "This is constant";
 // const data = "This is ajinkya";

echo data;


?>