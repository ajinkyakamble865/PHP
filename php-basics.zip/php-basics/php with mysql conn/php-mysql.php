<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "college";

$conn = new mysqli($host,$username,$password,$database);

if ($conn->connect_error) {
	die("connection faild".$conn->$connect_error);
}else{
	echo "database connected successfully<br>";
}

$result = $conn->query('show tables')->fetch_All();
print_r($result);
?>