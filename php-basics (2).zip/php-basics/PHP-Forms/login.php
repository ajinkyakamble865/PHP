<?php

if ($_GET) {
	echo "Name:".$_GET['name'];
	echo "<br>";
	echo "Password:".$_GET['password'];
}

?>