<?php

// print_r($_REQUEST);

foreach ($_REQUEST as $key => $value) {
	echo  $key." is ".$value;
	echo "<br>";
}
?>