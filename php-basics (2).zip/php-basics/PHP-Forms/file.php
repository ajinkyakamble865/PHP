<?php

if ($_FILES['file_upload']) {
	$path = $_FILES['file_upload']['name'];
	$upload_path = "uploads/".$path;
	
	if (move_uploaded_file( $_FILES['file_upload']['tmp_name'], $upload_path)) {
		echo "File upload successfully";
	}else{
		echo "File upload faild";
	}
}else{
	echo "file not found";
}
?>