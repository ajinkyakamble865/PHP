<?php

// print_r($_POST['btn'])

if (isset($_POST['btn'])) {
	if ($_POST['btn'] == "set") {
		$val = $_POST['name'];
		setcookie("user",$val);
		echo "cookie is set";
	}
	if ($_POST['btn'] == "display") {

		if (isset($_COOKIE['user'])) {
			echo $_COOKIE['user'];
		}
	} 

	if ($_POST['btn'] == "delete") {
		
		if (isset($_COOKIE['user'])) {
			setcookie("user",null,-1);
		}
	} 
	
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>cookies with html</title>
</head>
<body>
	<form action="" method="post">
		<input type="text" name="name" placeholder="Enter Your Name">
		<br>
		<br>
		<button name="btn" value="set">Set Cookie</button>
		<br>
		<br>
		<button name="btn" value="display">Display Cookie</button>
		<br>
		<br>
		<button name="btn" value="delete">Delete Cookie</button>
	</form>
</body>
</html>