<?php

$a = 10;

echo "<pre>";
print_r($GLOBALS);

$GLOBALS['a'] = "something";
print_r($GLOBALS);
?>