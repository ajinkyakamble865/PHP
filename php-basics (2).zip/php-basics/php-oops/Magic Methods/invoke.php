<?php 

class User{
	function __invoke(){
		echo "HI MY NAME IS AJINKYA";
	}

	function Other(){
		echo "test";
	}
}

$obj = new User();
$obj();

echo "<br>";
$obj->Other();
?>