<?php

class User {


	private function getName($name){
		echo "User name is $name";
	}

	function __call($method,$args){
		// echo "$method method is not exist";
		// print_r($args);
		if (method_exists($this,$method)) {
			call_user_func_array([$this,$method],$args);
		} else{
			echo "$method method is not exist";
		}
	}

}

$obj = new User();

$obj->getName("Ajinkya");

$obj->Other("aaa");

?>