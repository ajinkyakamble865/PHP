<?php 

if (isset($_POST['user'])) {
	class User{
		function getName($name){
			echo "User Name is $name";
		}
	}

	$user = new User();
	$user->getName($_POST['user']);
}else{ ?>

<form method="post">
	<input type="text" name="user" placeholder="Enter user name">
	<br>
	<br>
	<button>submit</button>
</form>

<?php } ?>