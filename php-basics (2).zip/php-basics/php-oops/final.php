<?php

/*final*/ class Honda
{
	final function carName()
	{
		echo "Honda";
	}
}

class Cars extends Honda
{
	function carName()
	{
		echo "Hyundie";
	}
}

$obj = new Cars();
$obj->carName();
?>