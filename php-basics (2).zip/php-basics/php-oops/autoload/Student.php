<?php

class Student
{
	
	function __construct()
	{
		echo "this is a Student class";
	}
}

?>