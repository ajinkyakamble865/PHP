<?php

class Managment
{
	
	function __construct()
	{
		echo "this is a Managment class";
	}
}

?>