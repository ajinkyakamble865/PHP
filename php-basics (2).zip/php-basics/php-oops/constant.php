<?php

class Constantdemo 
{
	protected const collegeName="KL College";
	function getcollegeNamge()
	{
		// echo self::collegeName;
		echo Constantdemo::collegeName;
	}
}

class childConst extends Constantdemo
{
	function getChildNamge()
	{
		echo self::collegeName;
	}
}
// echo Constantdemo::collegeName;

echo "<br>";

$obj = new Constantdemo();
$obj->getcollegeNamge();
echo "<br>";


// child class called constant
$childOBJ = new childConst();
$childOBJ->getChildNamge();

?>