<?php

class UserAuth{

	function Login($UserType)
	{
		echo "$UserType is Logged in";
	}
}


class student extends UserAuth
{
	function getName(){
		echo "Sam";
	}
}

$student = new student();
$student->Login("Ajinkya");
echo "<br>";
$student->getName();

?>