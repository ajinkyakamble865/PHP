<?php

include 'teacher.php';
include 'student.php';

$teacher = new teacher\JoiningDetails();
$teacher->JoiningDate();

echo "<br>";

$student = new student\JoiningDetails();
$student->addmissionDate();

?>