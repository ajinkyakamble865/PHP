<?php

	namespace student;
	
	class JoiningDetails
	{
		
		function addmissionDate()
		{
			echo "14/06/2022";
		}
	}


?>