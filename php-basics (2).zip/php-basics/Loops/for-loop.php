<?php

// $a = 0;

for ($i=1; $i <= 10; $i++) { 
	echo "Curreny value is $i<br>";
}

?>