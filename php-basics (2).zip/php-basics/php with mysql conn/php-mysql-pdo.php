<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "college";

try {
	$conn = new PDO("mysql:host=$host;dbname=$database;",$username,$password);
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	echo "Database Successfully Connected! <br>";
} catch (PDOException $err) {
	echo"Connection Faild $err->getMessage() <br>";
}

$result = $conn->query("show tables");
while ($row=$result->fetch(PDO::FETCH_NUM)) {
	print_r($row);
}

?>