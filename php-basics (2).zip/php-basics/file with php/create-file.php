<?php
if (isset($_POST['filename'])) {
	$filename = "files/".$_POST['filename'];
	$content = $_POST['content'];
	$file = fopen($filename, "w") or die('unable to create file');
	fwrite($file, $content);
	fclose($file);
	echo "file created";
}

	
?>

<form action="" method="post">
	<input type="text" name="filename" placeholder="Enter your file">
	<br>
	<br>
	<textarea name="content" placeholder="Add Your Content"></textarea>
	<br>
	<br>
	<button>Create File</button>
</form>