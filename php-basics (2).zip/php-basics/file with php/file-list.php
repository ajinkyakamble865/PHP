<?php

$path = "files";
$items = scandir($path);
$items = array_diff($items, [".",".."]);

// print_r($items);
foreach ($items as $item) {
	echo "<a href=files/$item>$item</a>";
	echo "<br>";
}

?>