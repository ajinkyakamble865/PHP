<?php

$users = ["Ajinkya","Peter","sam","bruce","tony","Ajinkya","sam"];
$user = ["Name"=>"Ajinkya","age"=>"21","email"=>"ajinkya@gmail.com"];

// is_array() check the variable is an array or not
if(is_array($users)){
	echo "this is an array!";
}else {
	echo "this is not an array";
}

echo "<br>";
echo count($users); // count array values
echo "<br>";

unset($users[1]); // remove the value
print_r($users);
echo "<br>";

array_push($users, "Shaktimaan"); //insert last element values in array
print_r($users);
echo "<br>";

array_pop($users); // remove the last element value
print_r($users);
echo "<br>";

print_r(array_keys($user)); // get only keys in array
echo "<br>";

echo implode(" ",$users); // convert array to string
echo "<br>";

$str = "hello how are you Ajinkya";
print_r(explode(" ", $str));
echo "<br>";

$data = array_merge($users,$user);// merge to array in one
print_r($data);
echo "<br>";

print_r(array_unique($users)); //remove the duplicate data
?>