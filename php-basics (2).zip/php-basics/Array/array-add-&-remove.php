<?php

$users = ["Ajinkya","Karan","sam"];

// add data in users array
array_push($users, "peter","om","ram");
print_r($users);
echo"<br>";


// remove last record in array
array_pop($users);
print_r($users);
echo"<br>";

// if you want to remove multi records at a time 
array_splice($users, -3);
print_r($users);
echo"<br>";
?>