<?php

$users = ["Ajinkya","sam","peter","bruce","karan"];

echo $users[0]."<br>"; //indexing print
echo $users[1]."<br>"; //indexing print
echo $users[2]."<br>"; //indexing print
echo $users[3]."<br>"; //indexing print


// array print by using a for loop
for ($user=0; $user < count($users) ; $user++) { 
	echo $users[$user];
	echo "<br>";
}
?>