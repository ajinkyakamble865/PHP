<?php
	
	date_default_timezone_set("Asia/Kolkata");

	echo "Today's date is ".date("d-m-y");
	echo "<br>";
	echo "Current time is ".date("h-i-sa");

?>