<?php

// diffence between include or require
// include : 	the include() statement generates a PHP alert but allows script execution 
//				to proceed if the fileto be included cannot be found.

// require : 	the require statement generates a fatal error and terminates the script.


// this is include statement
include 'test.php';
include 'test/testing.php';



// this is include_once statement check if is not exist then include_once is exicute
include_once 'test.php';


// this is require statement
require 'test.php';
require 'test/testing.php';


// this is require_once statement check if is not exist then require_once is exicute
require_once 'test.php';
?>