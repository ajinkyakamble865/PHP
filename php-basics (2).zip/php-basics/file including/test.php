<?php

echo"<h1 style='text-align: center;';>This Is Testing File</h1>";

?>