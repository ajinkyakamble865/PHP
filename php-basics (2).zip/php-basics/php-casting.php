<?php
$a = true;
$a = (string) $a;
var_dump($a);
echo "<br>";

$b = "100";
$b = (int) $b;
var_dump($b);
echo "<br>";

$c = 100;
$c = (float) $c;
var_dump($c);
echo "<br>";

$d = "abc";
$d = (bool) $d;
var_dump($d);
echo "<br>";

$d = 100;
$d = (array) $d;
var_dump($d);
echo "<br>";

$d = 100;
$d = (object) $d;
var_dump($d);
echo "<br>";

?>