<?php

function Name()
{
	// this is local variables
	$Name = "Ajinkya";
	echo $Name;
}

Name();

echo "<br>";


$user = "Ajinkya";

function FunctionName()
{
	// we can't access global variable directly
	// use global key word to access global variable

	global $user;

	$user = "Karan"; //changed the value

	echo $user;
}

FunctionName();

?>