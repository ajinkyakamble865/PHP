<?php

function userName()
{
	return "Ajinkya Kamble";
}

echo "<h2>Current user is ".userName()."</h2>";

?>