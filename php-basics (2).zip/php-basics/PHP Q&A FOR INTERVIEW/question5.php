<?php

function apple(){

	function banana(){
		echo "banana";
	}

	echo "apple";
}

echo apple().'<br>';

echo banana();

?>