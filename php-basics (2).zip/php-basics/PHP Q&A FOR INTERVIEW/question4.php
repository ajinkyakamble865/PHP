<?php

$num = [1,5,30,23,12,44,78];


$numCount = 0;
foreach ($num as $item) {
	$numCount++;
}
echo $numCount;

?>