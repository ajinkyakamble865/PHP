<?php

function callMe(){
	echo "function Called";
}

function callMe2(){
	echo "function 2 Called";
}

function apple($data){
	$data();
}


// apple('callMe');

if (false) {
	apple('callMe');
} else {
	apple('callMe2');
}



?>