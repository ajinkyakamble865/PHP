<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<?php include_once 'header.php'; ?>

		<h1 class="heading">Contact page</h1>

		<img src="images/abc.png" height="800px" width="1000px">
		<marquee><h2>PHP DEVELOPER</h2></marquee>
		<h2>Contact</h2>
		<div class="contact">
            <p>Email: <a href="mailto:ajinkyakamble865@gmail.com">ajinkyakamble865@gmail.com</a></p>
            <p>Phone: <a href="tel:+808008239">808008239</a> / <a href="tel:+8766752457">8766752457</a></p>
        </div>
		<?php include_once 'footer.php'; ?>
	</div>
</body>
</html>