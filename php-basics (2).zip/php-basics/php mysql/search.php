<form method="post">
	<input type="text" name="search" placeholder="Search" /><br><br>
	<button>Search</button>
</form>
<?php
include 'config.php';

if (isset($_POST['search'])) {
	$search = $_POST['search'];
	// $students = $conn->prepare("SELECT * FROM students WHERE name='$search'");
	$students = $conn->prepare("SELECT * FROM students WHERE name Like '%$search%'");
	$students->execute();
	$result = $students->fetchAll();
	// echo"<pre>";print_r($result);exit;
echo "<table border=1>
	<tr>
		<th>Name</th>
		<th>Course</th>
		<th>Batch</th>
		<th>Year</th>
	</tr>	
";

foreach ($result as $value) {
	echo "<tr>
			<td>".$value['name']."</td>
			<td>".$value['course']."</td>
			<td>".$value['batch']."</td>
			<td>".$value['year']."</td>
		</tr>";
}
echo "</table>";
}

?>