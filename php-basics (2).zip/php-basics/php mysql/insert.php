<form action="" method="post">
	<input type="text" name="name" placeholder="Enter Your Name"><br><br>
	<input type="text" name="course" placeholder="Enter Your Course"><br><br>
	<input type="text" name="batch" placeholder="Enter Your Batch"><br><br>
	<input type="text" name="year" placeholder="Enter Your Year"><br><br>
	<button>Add New Student</button>
</form>

<?php
include 'config.php';
if (isset($_POST['name'])) {
	$name = $_POST['name'];
	$course = $_POST['course'];
	$batch = $_POST['batch'];
	$year = $_POST['year'];
	$students = $conn->prepare("
	INSERT INTO `students` (id,name,course,batch,year) VALUES (NULL,'$name','$course','$batch','$year')
	");

	$result = $students->execute();
	if ($result) {
		echo "Data inserted";
	}else{
		echo "Operation failed";
	}
}
?>