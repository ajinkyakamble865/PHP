
<?php

include 'config.php';
$students = $conn->prepare("SELECT * FROM students");
$students->execute();
$StudentData = $students->fetchAll();

echo "<table border=1>
	<tr>
		<th>Name</th>
		<th>Course</th>
		<th>Batch</th>
		<th>Year</th>
		<th colspan='2'>Action</th>
	</tr>";
foreach ($StudentData as $student) {
	echo "<tr>
			<td>".$student['name']."</td>
			<td>".$student['course']."</td>
			<td>".$student['batch']."</td>
			<td>".$student['year']."</td>
			<td><form method='post' style='margin:0'><button name='delete' value=".$student['id'].">Delete</button></form></td>
			<td><button><a href='update.php?id=".$student['id']."'style='text-decoration:none;'>Edit</a></button></td>
		</tr>";
}
echo "</table>";

if (isset($_POST['delete'])) {
	$id = $_POST['delete'];
	$students = $conn->prepare("DELETE FROM students WHERE id=$id");
	if ($students->execute()) {
		echo "record deleted";
		header("Refresh : 0");
	}else{
		echo "record not deleted";
	}
}
?>