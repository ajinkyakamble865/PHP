<?php


// Assingment operator
$c = 5;
$d = 20;

echo "**********Assingment operators**********<br>";
echo $c = $d;   echo "<br>"; //simple assinged $d value in $c without any expression
echo $c += $d;  echo "<br>"; //$c = $c + $d  Assingment operator with Addition
echo $c -= $d;  echo "<br>"; //$c = $c - $d  Assingment operator with Subtraction
echo $c *= $d;  echo "<br>"; //$c = $c * $d  Assingment operator with Multiplication
echo $c /= $d;  echo "<br>"; //$c = $c / $d  Assingment operator with Division
echo $c %= $d;  echo "<br>"; //$c = $c % $d  Assingment operator with Modulus
echo $c **= $d; echo "<br>"; //$c = $c ** $d  Assingment operator with Exponentiation
echo "<br>";
echo "**********End**********<br><br>";
	

?>