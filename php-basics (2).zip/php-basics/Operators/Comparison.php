<?php

// Comparison operators

$e = 5;
$f = 20;
$g = 5;
$h = '20';
$i = 25;

echo "**********Comparison operators**********<br>";

// This is the equality operator, which checks if the values are the same.
var_dump($e == $f); // false because the values are not equal
echo "<br>";
var_dump($e == $g); // true because the values are equal
echo "<br>";
var_dump($f == $h); // true because the values are equal even though they have different data types
echo "<br><br>";

// This is the identical operator, which checks if the values and data types are the same.
var_dump($e === $f); // false because the values are not equal
echo "<br>";
var_dump($e === $g); // true because both the values and data types are equal
echo "<br>";
var_dump($f === $h); // false because the values are equal but the data types are different
echo "<br><br>";

// This is the not equal operator, which returns true when the values are different.
var_dump($e != $f); // true because the values are not equal
echo "<br>";
var_dump($e != $g); // false because the values are equal
echo "<br>";
var_dump($f != $h); // false because the values are equal even with different data types
echo "<br><br>";

// This is another syntax for the not equal operator.
var_dump($e <> $f); // true because the values are not equal
echo "<br>";
var_dump($e <> $g); // false because the values are equal
echo "<br>";
var_dump($f <> $h); // false because the values are equal even with different data types
echo "<br><br>";

// This is the not identical operator, which returns true if $x is not equal to $y or they are not of the same type.
var_dump($e !== $f); // true because the values are not equal
echo "<br>";
var_dump($e !== $g); // false because both the values and data types are equal
echo "<br>";
var_dump($f !== $h); // true because the values are equal but the data types are different
echo "<br><br>";

// This is the greater than operator, which returns true if $x is greater than $y.
var_dump($e > $f); // false because $e is less than $f
echo "<br>";
var_dump($e > $g); // false because the values are equal
echo "<br>";
var_dump($f > $g); // true because $f is greater than $g
echo "<br>";
var_dump($i > $h); // true because $i is greater than $h
echo "<br><br>";

// This is the less than operator, which returns true if $x is less than $y.
var_dump($e < $f); // true because $e is less than $f
echo "<br>";
var_dump($e < $g); // false because the values are equal
echo "<br>";
var_dump($f < $g); // false because $f is greater than $g
echo "<br>";
var_dump($i < $h); // false because $i is greater than $h
echo "<br><br>";

// This is the greater than or equal to operator, which returns true if $x is greater than or equal to $y.
var_dump($e >= $f); // false because $e is less than $f
echo "<br>";
var_dump($e >= $g); // true because the values are equal
echo "<br>";
var_dump($f >= $g); // true because $f is greater than $g
echo "<br>";
var_dump($i >= $h); // true because $i is greater than $h
echo "<br><br>";

// This is the less than or equal to operator, which returns true if $x is less than or equal to $y.
var_dump($e <= $f); // true because $e is less than $f
echo "<br>";
var_dump($e <= $g); // true because the values are equal
echo "<br>";
var_dump($f <= $g); // false because $f is greater than $g
echo "<br>";
var_dump($i <= $h); // false because $i is greater than $h
echo "<br><br>";

// This is the spaceship operator, which compares two values.
echo '$e <=> $f: ' . ($e <=> $f); // -1 because $e is less than $f
echo "<br>";
echo '$e <=> $g: ' . ($e <=> $g); // 0 because the values are equal
echo "<br>";
echo '$f <=> $g: ' . ($f <=> $g); // 1 because $f is greater than $g
echo "<br>";
echo '$i <=> $h: ' . ($i <=> $h); // 1 because $i is greater than $h
echo "<br><br>";

echo "**********End**********<br><br>";
?>
