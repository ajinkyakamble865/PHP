<?php


// Logical operator
// and == &&
// or == ||
// Xor
// Not



$a = 10;
$b = 20;

// this is And operator return true  if both is true
if($a==10 and $b==20){
	echo"the value is true<br>";
}else{
	echo"the value is false <br>";
}

$ternaryVal = ($a==10 && $b==20) ? 'true' : 'false';
echo $ternaryVal;
// this is And operator


// this is Or operator return true  if either is true
echo"<br>";
if($a==10 or $b==0){
	echo"the value is true<br>";
}else{
	echo"the value is false <br>";
}

$ternaryVal = ($a==0 || $b==0) ? 'true' : 'false';
echo $ternaryVal;
// this is Or operator


// this is Xor operator return true if only one value is true
echo"<br>";
if($a==10 xor $b==0){
	echo"Condition is true<br>";
}else{
	echo"Condition is false <br>";
}
// this is Xor operator


// this is Not operator return true True if $a is not true
if($a!=0){
	echo"Condition is true<br>";
}else{
	echo"Condition is false <br>";
}

// this is Not operator
?>